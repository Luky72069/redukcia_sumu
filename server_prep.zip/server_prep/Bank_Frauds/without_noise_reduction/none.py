# import os
# # Nastavenie poctu pouzivanych procesorov
# os.environ['OMP_NUM_THREADS'] = '15'
# os.environ['OPENBLAS_NUM_THREADS'] = '15'
# os.environ['MKL_NUM_THREADS'] = '15'
# os.environ['VECLIB_MAXIMUM_THREADS'] = '15'
# os.environ['NUMEXPR_NUM_THREADS'] = '15'

import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier
from imblearn.ensemble import EasyEnsembleClassifier
from sklearn.svm import SVC
from xgboost import XGBClassifier
from sklearn.neighbors import NearestNeighbors
from sklearn.model_selection import StratifiedKFold, cross_val_predict
from sklearn.metrics import make_scorer
from sklearn.metrics import accuracy_score, f1_score, roc_auc_score
from imblearn.metrics import geometric_mean_score
from collections import Counter
from sklearn.model_selection import GridSearchCV
from sklearn.preprocessing import StandardScaler
import time

# Filter warnings
import warnings
warnings.filterwarnings('ignore')

# Časová stopka - začiatok
# start_time = time.time()

# Definícia vlastnej metriky hodnotenia s použitím geometrického priemeru
def custom_metric(y_true, y_pred):
    gm = geometric_mean_score(y_true, y_pred)
    return gm

# Vyhodnotenie metrík
def evaluate_metrics(y_true, y_pred):
    acc = accuracy_score(y_true, y_pred)
    f1 = f1_score(y_true, y_pred)
    auc = roc_auc_score(y_true, y_pred)
    gm = geometric_mean_score(y_true, y_pred)
    return acc, f1, auc, gm

# Ukladanie metrik
def save_report(classifier, sampling, size, acc, f1, auc, gm):
    classifier_name = classifier.__class__.__name__
    sampling_name = sampling.__class__.__name__

    # Kontrola existencie souboru
    try:
        existing_metrics_df = pd.read_csv('../report.csv')
        if existing_metrics_df.empty or existing_metrics_df.columns[0] == 'Unnamed: 0':
            existing_metrics_df = pd.DataFrame()

    except (FileNotFoundError, pd.errors.EmptyDataError):
        existing_metrics_df = pd.DataFrame()
        # Vytvorenie prazdneho suboru, ak neexistuje
        existing_metrics_df.to_csv('../report.csv', index=False)

    # Vytvorenie DataFrame pre nove metriky
    metrics_df = pd.DataFrame({
        'Classifier': [classifier_name] * 4,
        'Sampling': [sampling_name] * 4,
        'train/clean/oversampled/test': [size] * 4,
        'Metric': ['Accuracy', 'F1 Score', 'ROC AUC', 'Geometric Mean'],
        'Value': [acc, f1, auc, gm]
    })

    # Pridanie novych metrik k existujícím
    updated_metrics_df = pd.concat([existing_metrics_df, metrics_df], ignore_index=True)

    # Pridanie prazdneho riadku
    updated_metrics_df = pd.concat([updated_metrics_df, pd.DataFrame([[]])], ignore_index=True)

    # ulozenie do CSV souboru
    updated_metrics_df.to_csv('../report.csv', index=False)

def is_danger(nn_indices, y):
    minority_nn_count = 0
    majority_n_count = 0
    for i in nn_indices:
        if y[i] == 1:
            minority_nn_count += 1
        else:
            majority_n_count += 1

    if minority_nn_count < majority_n_count:
        return 1
    else:
        return 0

def select_k_nearest_neighbors(X, xi, k):
    # nn = NearestNeighbors(n_neighbors=k, n_jobs=15).fit(X)
    nn = NearestNeighbors(n_neighbors=k).fit(X)
    _, indices = nn.kneighbors(xi.reshape(1, -1), n_neighbors=k)
    selected_indices = []
    for idx in indices[0]:
        selected_indices.append(idx)
    return selected_indices

def NRBSID(X, y, k):
    Removals = []

    # print("Veľkosť pôvodného datasetu pred fázou Noise Reduction:", X.shape, y.shape)

    # for i in range(len(X)):
    #     xi = X[i]
    #     if y[i] == 1:
    #         nn_indices = select_k_nearest_neighbors(X, xi, k)
    #         if is_danger(nn_indices, y):
    #             Removals.append(xi)
    #     else:
    #         continue

    Removals = np.array(Removals)
    common_indices = np.where(np.all(np.isin(X, Removals, assume_unique=True), axis=1))[0]
    X_cleaned = X
    y_cleaned = y

    # print("Veľkosť datasetu po vymazani po Noise Reduction:", X_cleaned.shape, y_cleaned.shape)

    # ///// none /////
    X_oversampled, y_oversampled = X_cleaned, y_cleaned

    sampling = 'none'

    # print("Veľkosť resampleovaného datasetu:", X_oversampled.shape, y_oversampled.shape)

    return X_oversampled, y_oversampled, Removals, sampling, X_cleaned
# ----------------------------------------- DATASET --------------------------------------------------------------------
print("none ..... start")
# import dataset
# Read the CSV file into a Pandas DataFrame
df = pd.read_csv("../Base.csv")

# Create a deep copy of the DataFrame
new_df = df.copy()

# Get the number of rows and columns in the DataFrame
df_shape = df.shape
# print("Number of rows:", df_shape[0])
# print("Number of columns:", df_shape[1])

# Create a new DataFrame showing the count of unique values in the 'fraud_bool' column
fraud_vals = pd.DataFrame(df['fraud_bool'].value_counts())

# Reset the index of the DataFrame and rename the columns
fraud_vals.reset_index(inplace=True)
fraud_vals.rename(columns={'index': 'fraud_bool', 'fraud_bool': 'count'}, inplace=True)

# Initialize an empty DataFrame to hold the percentage of missing values for each feature
missing_vals = pd.DataFrame()

# List of features to check for missing values
missing_features = ['prev_address_months_count', 'current_address_months_count', 'intended_balcon_amount', 'bank_months_count', 'session_length_in_minutes', 'device_distinct_emails_8w']

# For each feature, replace -1 values with NaN, calculate the percentage of missing values, and add to the missing_vals DataFrame
for feature in missing_features:
    df.loc[df[feature] < 0, feature] = np.nan # df[feature] = df[feature].replace(-1, np.nan)
    missing_vals_col = df.groupby('fraud_bool')[feature].apply(lambda x: round(x.isna().sum()/len(x) * 100, 2))
    missing_vals[feature] = missing_vals_col

# Reshape the missing_vals DataFrame from wide to long format
missing_vals = pd.DataFrame(missing_vals.T.stack())

# Reset the index and rename the columns
missing_vals.reset_index(inplace=True)
missing_vals.rename(columns={'level_0': 'feature', 0: 'missing_vals'}, inplace=True)

# Create a list of categorical features in the DataFrame new_df whose data type is `object`
categorical_features = [x for x in new_df.columns if new_df[x].dtypes == "O"]

# Convert categorical variables into dummy variables using one-hot encoding
new_df = pd.DataFrame(pd.get_dummies(new_df, prefix=categorical_features))

# ----------------------------------------------------------------------------- CUT 90% off
# print(new_df.shape[0])

# dataset na dva podmnoziny
fraud_0 = new_df[new_df['fraud_bool'] == 0]
fraud_1 = new_df[new_df['fraud_bool'] == 1]

# pocet prvkov
num_to_keep = int(0.025 * len(fraud_0))  # 10% 'fraud_bool' == 0
num_to_keep_fraud_1 = int(0.025 * len(fraud_1))  # 10% 'fraud_bool' == 1

# random vyber 10%
fraud_0_subset = fraud_0.sample(n=num_to_keep, random_state=42)
fraud_1_subset = fraud_1.sample(n=num_to_keep_fraud_1, random_state=42)

# spojenie
data_subset = pd.concat([fraud_0_subset, fraud_1_subset])

new_df = data_subset
# print(new_df.shape[0])
# ----------------------------------------------------------------------------- CUT 90% off

# Separate the feature matrix and target variable
X = new_df.drop(['fraud_bool'], axis=1)
y = new_df['fraud_bool'].values.reshape(-1, 1)

X_final, y_final = X, y
# ----------------------------------------------------------------------------------------------------------------------
# Spustenie algoritmu NRBSID s Borderline SMOTE
k = 5

# print("\nVeľkosť pôvodného datasetu:", X_final.shape, y_final.shape)

y_final_reshaped = y_final.flatten()
y_counter = Counter(y_final_reshaped)
# print("Počet hodnôt 0 v y_final:", y_counter[0])
# print("Počet hodnôt 1 v y_final:", y_counter[1])

# -------------------------------- SPLIT 80-20/SCALER ------------------------------------------------------------------
# Rozdelenie na trénovaciu a testovaciu množinu
X_train, X_test, y_train, y_test = train_test_split(X_final, y_final_reshaped, test_size=0.2, random_state=42, stratify=y_final)

# print("\n----------------------------------")
# print("Veľkosť X_train, y_train:", X_train.shape, y_train.shape)
y_train_reshape = y_train.flatten()
y_counter_y_train = Counter(y_train_reshape)
# print("Počet hodnôt 0 v y_train:", y_counter_y_train[0])
# print("Počet hodnôt 1 v y_train:", y_counter_y_train[1])
# print("----------------------------------")

# Škálovanie trénovacích dát
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)

# print("\n----------------------------------")
# print("Veľkosť X_test, y_test:", X_test.shape, y_test.shape)
y_test_reshape = y_test.flatten()
y_counter_y_test = Counter(y_test_reshape)
# print("Počet hodnôt 0 v y_test:", y_counter_y_test[0])
# print("Počet hodnôt 1 v y_test:", y_counter_y_test[1])
# print("----------------------------------")

# Škálovanie testovacích dát
X_test_scaled = scaler.transform(X_test)

# ------------------------------------------ NOISE REDUCTION -----------------------------------------------------------
print("redukcia sumu (none) ..... start")
X_oversampled, y_oversampled, removed_samples, sampling, X_clean = NRBSID(X_train_scaled, y_train, k)
print("redukcia sumu (none) ..... end")
# print("podovodny: ", X_train_scaled.shape[0])
# print("cisty: ", X_clean.shape[0])
# print("oversample: ", X_oversampled.shape[0])
# print("testovacia cast:", X_test_scaled.shape[0])

size = [X_train_scaled.shape[0], X_clean.shape[0], X_oversampled.shape[0], X_test_scaled.shape[0]]

# print("Veľkosť pôvodného datasetu:", X_final.shape, y_final.shape)
# print("Veľkosť výsledného datasetu:", X_oversampled.shape, y_oversampled.shape)

y_oversampled_counter = Counter(y_oversampled)
# print("\nPočet hodnôt 0 v y_oversampled:", y_oversampled_counter[0])
# print("Počet hodnôt 1 v y_oversampled:", y_oversampled_counter[1])


# Stratifikovaná krížová validácia
skf = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)

# Vytvorenie objektu make_scorer s použitím vlastnej metriky
scorer = make_scorer(custom_metric)
# --------------------------------------------- CLASSIFIERS ------------------------------------------------------------
print("DT (none) ..... start")
# Decision Tree
classifier_dt = DecisionTreeClassifier(random_state=42)

# Tunovanie hyperparametrov pre model Decision Tree
param_grid_dt = {
    'max_depth': [3, 5, 7, 10],
    'min_samples_split': [2, 5, 10],
    'min_samples_leaf': [1, 2, 4],
    'max_features': [None, 'sqrt', 'log2']
}

# grid_search_dt = GridSearchCV(classifier_dt, param_grid_dt, cv=skf, scoring=scorer, n_jobs=15)
grid_search_dt = GridSearchCV(classifier_dt, param_grid_dt, cv=skf, scoring=scorer)
grid_search_dt.fit(X_oversampled, y_oversampled)

best_model_dt = grid_search_dt.best_estimator_

# Predikcia s modelom po tunovaní
y_pred_tuned_dt = cross_val_predict(best_model_dt, X_test_scaled, y_test, cv=skf)

# Vyhodnotenie metrík pre tunovaný model
acc_tuned_dt, f1_tuned_dt, auc_tuned_dt, gm_tuned_dt = evaluate_metrics(y_test, y_pred_tuned_dt)
# ---------------------------------- SAVE RESULT -----------------------------------------------------------------------
save_report(classifier_dt, sampling, size, acc_tuned_dt, f1_tuned_dt, auc_tuned_dt, gm_tuned_dt)
print("DT (none) ..... end")
# ----------------------------------------------------------------------------------------------------------------------
print("EE (none) ..... start")
# EasyEnsemble
classifier_ee = EasyEnsembleClassifier(
    n_estimators=10,
    random_state=42
)

# Tuning hyperparameters for EasyEnsemble
param_grid_ee = {
    'n_estimators': [10, 20, 30],
    'replacement': [True, False],
    'sampling_strategy': ['auto', 0.5, 0.7, 1.0],
    'verbose': [0],
}

# grid_search_ee = GridSearchCV(classifier_ee, param_grid_ee, cv=skf, scoring=scorer, n_jobs=15)
grid_search_ee = GridSearchCV(classifier_ee, param_grid_ee, cv=skf, scoring=scorer)
grid_search_ee.fit(X_oversampled, y_oversampled)

best_model_ee = grid_search_ee.best_estimator_

# Predikcia s modelom po tunovaní
y_pred_tuned_ee = cross_val_predict(best_model_ee, X_test_scaled, y_test, cv=skf)

# Vyhodnotenie metrík pre tunovaný model
acc_tuned_ee, f1_tuned_ee, auc_tuned_ee, gm_tuned_ee = evaluate_metrics(y_test, y_pred_tuned_ee)
# ---------------------------------- SAVE RESULT -----------------------------------------------------------------------
save_report(classifier_ee, sampling, size, acc_tuned_ee, f1_tuned_ee, auc_tuned_ee, gm_tuned_ee)
print("EE (none) ..... end")
# ----------------------------------------------------------------------------------------------------------------------
print("SVC (none) ..... start")
# SVC_rbf
classifier_svc = SVC(probability=True, random_state=42)

# Tunovanie hyperparametrov pre model SVC
param_grid_svc = {
    'C': [0.01, 0.1, 1, 10],
    'kernel': ['rbf'],
    'gamma': [0.01, 0.1, 1, 10],
}


# grid_search_svc = GridSearchCV(classifier_svc, param_grid_svc, cv=skf, scoring=scorer, n_jobs=15)
grid_search_svc = GridSearchCV(classifier_svc, param_grid_svc, cv=skf, scoring=scorer)
grid_search_svc.fit(X_oversampled, y_oversampled)

best_model_svc = grid_search_svc.best_estimator_

# Predikcia s modelom po tunovaní
y_pred_tuned_svc = cross_val_predict(best_model_svc, X_test_scaled, y_test, cv=skf)

# Vyhodnotenie metrík pre tunovaný model
acc_tuned_svc, f1_tuned_svc, auc_tuned_svc, gm_tuned_svc = evaluate_metrics(y_test, y_pred_tuned_svc)
# ---------------------------------- SAVE RESULT -----------------------------------------------------------------------
save_report(classifier_svc, sampling, size, acc_tuned_svc, f1_tuned_svc, auc_tuned_svc, gm_tuned_svc)
print("SVC (none) ..... end")
# ----------------------------------------------------------------------------------------------------------------------
print("XGB (none) ..... start")
# XGBoost
classifier_xgb = XGBClassifier(random_state=42)

# Tunovanie hyperparametrov pre model XGBoost
param_grid_xgb = {
    'learning_rate': [0.01, 0.1, 0.2],
    'n_estimators': [50, 100, 200],
    'max_depth': [3, 5, 7],
    'min_child_weight': [1, 3, 5],
    'subsample': [0.8, 0.9, 1.0],
    'colsample_bytree': [0.8, 0.9, 1.0],
}

# grid_search_xgb = GridSearchCV(classifier_xgb, param_grid_xgb, cv=skf, scoring=scorer, n_jobs=15)
grid_search_xgb = GridSearchCV(classifier_xgb, param_grid_xgb, cv=skf, scoring=scorer)
grid_search_xgb.fit(X_oversampled, y_oversampled)

best_model_xgb = grid_search_xgb.best_estimator_

# Predikcia s modelom po tunovaní
y_pred_tuned_xgb = cross_val_predict(best_model_xgb, X_test_scaled, y_test, cv=skf)

# Vyhodnotenie metrík pre tunovaný model
acc_tuned_xgb, f1_tuned_xgb, auc_tuned_xgb, gm_tuned_xgb = evaluate_metrics(y_test, y_pred_tuned_xgb)
# ---------------------------------- SAVE RESULT -----------------------------------------------------------------------
save_report(classifier_xgb, sampling, size, acc_tuned_xgb, f1_tuned_xgb, auc_tuned_xgb, gm_tuned_xgb)
print("XGB (none) ..... end")
# ----------------------------------------------------------------------------------------------------------------------



#
# print("\nTuned Decision Tree:")
# print("Presnosť (Accuracy):", acc_tuned_ee)
# print("F1 skóre:", f1_tuned_ee)
# print("AUC skóre:", auc_tuned_ee)
# print("Geometrický priemer (GM):", gm_tuned_ee)

# Časová stopka - koniec
# end_time = time.time()
# execution_time = end_time - start_time
# print("\nČas vykonávania kódu:", execution_time, "sekundy")
print("none ..... end")